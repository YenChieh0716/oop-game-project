//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by game.rc
//
#define IDD_ABOUTBOX                    100
#define IDP_SOCKETS_INIT_FAILED         104
#define IDR_MAINFRAME                   128
#define IDR_GAMETYPE                    129
#define IDC_README                      1001
#define ID_FILE_PAUSE                   32771
#define ID_TOGGLE_FULLSCREEN            32772
#define ID_BUTTON_FULLSCREEN            32773
#define ID_BUTTON_PAUSE                 32774
#define ID_BUTTON_UNITTEST              32775

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        157
#define _APS_NEXT_COMMAND_VALUE         32776
#define _APS_NEXT_CONTROL_VALUE         1003
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
